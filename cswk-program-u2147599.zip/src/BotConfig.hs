{-# LANGUAGE OverloadedStrings #-}
module BotConfig where

import Data.Text (Text)

cfDiscordToken :: Text
cfMongoHost :: String
cfLeaderboardSize :: Int

cfDiscordToken = "OTU0NDMxOTg0MTM3MDM1OTA2.YjTCDQ.RwhUfmQnjm6qQCrmSidJvdObQps"
cfMongoHost = "127.0.0.1"
cfLeaderboardSize = 10